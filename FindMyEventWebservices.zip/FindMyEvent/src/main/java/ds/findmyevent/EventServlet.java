package ds.findmyevent;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import com.google.gson.Gson;


@WebServlet("/events")
public class EventServlet extends HttpServlet {
    private TicketMasterService ticketmasterService;
    private MongoDBRepository mongoRepository;
    private Gson gson;

    @Override
    public void init() throws ServletException {
        // Initialize your services
        ticketmasterService = new TicketMasterService("9FWucIcOcnrx039RJI3Xl4CFE8uDbnok");
        mongoRepository = new MongoDBRepository("mongodb+srv://tangridhruv:QAZwsxEDC123@cluster0.04eod.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", "project4db", "events");
        gson = new Gson();

        try {
            mongoRepository.connect();
        } catch (Exception e) {
            throw new ServletException("Failed to connect to MongoDB", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Start timing for response time tracking
        long startTime = System.currentTimeMillis();

        // Log the request and get log ID for tracking
        String logId = logRequest(request);

        // Parse parameters
        String searchType = request.getParameter("searchType");
        String query = request.getParameter("query");

        try {
            // Call the Ticketmaster API
            List<Event> events;

            if ("name".equals(searchType)) {
                events = ticketmasterService.searchByName(query, 10);
            } else if ("country".equals(searchType)) {
                events = ticketmasterService.searchByCountry(query, 10);
            } else {
                events = ticketmasterService.getAllEvents(10);
            }

            // Store events in MongoDB
            mongoRepository.saveEvents(events);

            // Return JSON response
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            PrintWriter out = response.getWriter();
            out.print(gson.toJson(events));
            out.flush();

            // Calculate response time
            long responseTime = System.currentTimeMillis() - startTime;

            // Log the response
            logResponse(logId, events, responseTime);

        } catch (Exception e) {
            // Handle errors
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().println("{\"error\": \"" + e.getMessage() + "\"}");

            // Log the error
            logError(logId, e);
        }
    }

    private String logRequest(HttpServletRequest request) {
        try {
            // Get request parameters
            String searchType = request.getParameter("searchType");
            if (searchType == null) searchType = "all"; // Default if not specified

            String query = request.getParameter("query");
            if (query == null) query = ""; // Default if not specified

            // Log the request to MongoDB
            return mongoRepository.logRequest(
                    request.getRemoteAddr(),
                    request.getHeader("User-Agent"),
                    request.getMethod(),
                    request.getRequestURI(),
                    searchType,
                    query
            );
        } catch (Exception e) {
            System.err.println("Error logging request: " + e.getMessage());
            e.printStackTrace();
            return null; // Return null if logging fails
        }
    }

    private void logResponse(String logId, List<Event> events, long responseTime) {
        try {
            if (logId != null) {
                // Log response details to MongoDB
                mongoRepository.logResponse(
                        logId,
                        "success",
                        events.size(),
                        responseTime
                );
            }
        } catch (Exception e) {
            System.err.println("Error logging response: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void logError(String logId, Exception e) {
        try {
            if (logId != null) {
                // Log error details to MongoDB
                mongoRepository.logError(
                        logId,
                        e.getMessage(),
                        e.getClass().getName()
                );
            }
        } catch (Exception ex) {
            System.err.println("Error logging error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        // Clean up resources
        if (mongoRepository != null) {
            mongoRepository.close();
        }
    }
}