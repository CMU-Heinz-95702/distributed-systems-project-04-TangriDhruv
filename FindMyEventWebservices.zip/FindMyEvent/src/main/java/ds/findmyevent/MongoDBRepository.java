package ds.findmyevent;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.FindOneAndReplaceOptions;
import com.mongodb.client.model.ReturnDocument;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.AggregateIterable;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;

/**
 * Repository class for MongoDB operations including event storage and logging
 *
 * @author [Your Name] [Your Andrew ID]
 */
public class MongoDBRepository {
    private final String connectionString;
    private final String databaseName;
    private final String collectionName;
    private MongoClient mongoClient;
    private MongoCollection<Document> collection;
    private MongoCollection<Document> logsCollection;

    /**
     * Constructor with connection details
     *
     * @param connectionString MongoDB connection string
     * @param databaseName Database name
     * @param collectionName Collection name
     */
    public MongoDBRepository(String connectionString, String databaseName, String collectionName) {
        this.connectionString = connectionString;
        this.databaseName = databaseName;
        this.collectionName = collectionName;
    }

    /**
     * Connect to MongoDB
     *
     * @throws Exception If connection fails
     */
    public void connect() throws Exception {
        try {
            mongoClient = MongoClients.create(connectionString);
            MongoDatabase database = mongoClient.getDatabase(databaseName);
            collection = database.getCollection(collectionName);

            // Initialize logs collection
            logsCollection = database.getCollection("logs");

            System.out.println("Connected to MongoDB Atlas successfully!");
        } catch (Exception e) {
            throw new Exception("Failed to connect to MongoDB: " + e.getMessage());
        }
    }

    /**
     * Close MongoDB connection
     */
    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
            System.out.println("MongoDB connection closed.");
        }
    }

    /**
     * Get the logs collection
     *
     * @return MongoDB collection for logs
     */
    public MongoCollection<Document> getLogsCollection() {
        return logsCollection;
    }

    /**
     * Save an event to MongoDB (upsert operation)
     *
     * @param event The event to save
     * @return The saved event
     */
    public Event saveEvent(Event event) {
        Document eventDoc = convertEventToDocument(event);

        // Create a filter based on the event ID
        Bson filter = Filters.eq("_id", event.getId());

        // Set upsert option (update if exists, insert if not)
        FindOneAndReplaceOptions options = new FindOneAndReplaceOptions()
                .upsert(true)
                .returnDocument(ReturnDocument.AFTER);

        // Perform upsert and get the result
        Document result = collection.findOneAndReplace(filter, eventDoc, options);

        return convertDocumentToEvent(result);
    }

    /**
     * Save multiple events to MongoDB
     *
     * @param events List of events to save
     * @return Number of events saved
     */
    public int saveEvents(List<Event> events) {
        int count = 0;
        for (Event event : events) {
            saveEvent(event);
            count++;
        }
        return count;
    }

    /**
     * Retrieve all events from MongoDB
     *
     * @param limit Maximum number of events to retrieve (0 for all)
     * @return List of events
     */
    public List<Event> getAllEvents(int limit) {
        List<Event> events = new ArrayList<>();

        MongoCursor<Document> cursor;
        if (limit > 0) {
            cursor = collection.find().limit(limit).iterator();
        } else {
            cursor = collection.find().iterator();
        }

        try {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                events.add(convertDocumentToEvent(doc));
            }
        } finally {
            cursor.close();
        }

        return events;
    }

    /**
     * Log a request to MongoDB
     *
     * @param clientIp The client's IP address
     * @param userAgent The client's user agent
     * @param method The HTTP method (GET, POST, etc.)
     * @param requestPath The request path
     * @param searchType The type of search (name, country, all)
     * @param query The search query
     * @return The ID of the created log document
     */
    public String logRequest(String clientIp, String userAgent, String method,
                             String requestPath, String searchType, String query) {
        Document logDoc = new Document();

        // Generate a unique ID for this log entry
        String logId = java.util.UUID.randomUUID().toString();

        // Log timestamp and request information
        logDoc.append("_id", logId)
                .append("timestamp", System.currentTimeMillis())
                .append("date", new Date())
                .append("clientIp", clientIp)
                .append("userAgent", userAgent)
                .append("method", method)
                .append("requestPath", requestPath)
                .append("searchType", searchType)
                .append("query", query)
                .append("requestTimestamp", System.currentTimeMillis());

        // Insert the log document
        logsCollection.insertOne(logDoc);

        return logId;
    }

    /**
     * Update a log entry with response information
     *
     * @param logId The ID of the log to update
     * @param status The response status (success/error)
     * @param resultCount Number of results
     * @param responseTime Response processing time in ms
     */
    public void logResponse(String logId, String status, int resultCount, long responseTime) {
        Bson filter = Filters.eq("_id", logId);

        Document update = new Document("$set", new Document()
                .append("status", status)
                .append("resultCount", resultCount)
                .append("responseTime", responseTime)
                .append("responseTimestamp", System.currentTimeMillis()));

        logsCollection.updateOne(filter, update);
    }

    /**
     * Log an error that occurred during request processing
     *
     * @param logId The ID of the log to update
     * @param errorMessage The error message
     * @param errorType The type/class of the error
     */
    public void logError(String logId, String errorMessage, String errorType) {
        Bson filter = Filters.eq("_id", logId);

        Document update = new Document("$set", new Document()
                .append("status", "error")
                .append("errorMessage", errorMessage)
                .append("errorType", errorType)
                .append("responseTimestamp", System.currentTimeMillis()));

        logsCollection.updateOne(filter, update);
    }

    /**
     * Retrieve recent logs from MongoDB
     *
     * @param limit Maximum number of logs to retrieve
     * @return List of log documents
     */
    public List<Document> getRecentLogs(int limit) {
        List<Document> logs = new ArrayList<>();

        logsCollection.find()
                .sort(Sorts.descending("timestamp"))
                .limit(limit)
                .into(logs);

        return logs;
    }

    /**
     * Get analytics data for the dashboard
     *
     * @return Map of analytics data
     */
    public Map<String, Object> getAnalytics() {
        Map<String, Object> analytics = new HashMap<>();

        // Total number of requests
        analytics.put("totalRequests", logsCollection.countDocuments());

        // Calculate average response time
        List<Document> pipeline = Arrays.asList(
                new Document("$match", new Document("responseTime", new Document("$exists", true))),
                new Document("$group", new Document("_id", null)
                        .append("avgResponseTime", new Document("$avg", "$responseTime")))
        );

        Document avgResponseResult = logsCollection.aggregate(pipeline).first();
        if (avgResponseResult != null) {
            analytics.put("avgResponseTime", avgResponseResult.getDouble("avgResponseTime"));
        } else {
            analytics.put("avgResponseTime", 0);
        }

        // Most popular search term
        pipeline = Arrays.asList(
                new Document("$match", new Document("query", new Document("$exists", true)
                        .append("$ne", null)
                        .append("$ne", ""))),
                new Document("$group", new Document("_id", "$query")
                        .append("count", new Document("$sum", 1))),
                new Document("$sort", new Document("count", -1)),
                new Document("$limit", 1)
        );

        Document popularSearchResult = logsCollection.aggregate(pipeline).first();
        if (popularSearchResult != null) {
            analytics.put("popularSearchTerm", popularSearchResult.getString("_id"));
            analytics.put("popularSearchCount", popularSearchResult.getInteger("count"));
        } else {
            analytics.put("popularSearchTerm", "None");
            analytics.put("popularSearchCount", 0);
        }

        // Most common search type
        pipeline = Arrays.asList(
                new Document("$match", new Document("searchType", new Document("$exists", true)
                        .append("$ne", null)
                        .append("$ne", ""))),
                new Document("$group", new Document("_id", "$searchType")
                        .append("count", new Document("$sum", 1))),
                new Document("$sort", new Document("count", -1)),
                new Document("$limit", 1)
        );

        Document searchTypeResult = logsCollection.aggregate(pipeline).first();
        if (searchTypeResult != null) {
            analytics.put("mostCommonSearchType", searchTypeResult.getString("_id"));
            analytics.put("searchTypeCount", searchTypeResult.getInteger("count"));
        } else {
            analytics.put("mostCommonSearchType", "None");
            analytics.put("searchTypeCount", 0);
        }

        return analytics;
    }

    /**
     * Convert Event object to MongoDB Document
     *
     * @param event The event to convert
     * @return MongoDB Document
     */
    private Document convertEventToDocument(Event event) {
        Document doc = new Document();

        doc.append("_id", event.getId());
        doc.append("name", event.getName());

        // Add date information
        if (event.getLocalDate() != null || event.getLocalTime() != null) {
            Document dateDoc = new Document();
            if (event.getLocalDate() != null) {
                dateDoc.append("localDate", event.getLocalDate());
            }
            if (event.getLocalTime() != null) {
                dateDoc.append("localTime", event.getLocalTime());
            }
            doc.append("date", dateDoc);
        }

        // Add venue and location information
        if (event.getVenueName() != null || event.getCity() != null ||
                event.getState() != null || event.getCountry() != null) {

            Document venueDoc = new Document();
            if (event.getVenueName() != null) {
                venueDoc.append("name", event.getVenueName());
            }

            Document locationDoc = new Document();
            if (event.getCity() != null) {
                locationDoc.append("city", event.getCity());
            }
            if (event.getState() != null) {
                locationDoc.append("state", event.getState());
            }
            if (event.getCountry() != null) {
                locationDoc.append("country", event.getCountry());
            }

            if (!locationDoc.isEmpty()) {
                venueDoc.append("location", locationDoc);
            }

            if (!venueDoc.isEmpty()) {
                doc.append("venue", venueDoc);
            }
        }

        // Add price information
        if (event.getMinPrice() != null || event.getMaxPrice() != null || event.getCurrency() != null) {
            Document priceDoc = new Document();
            if (event.getMinPrice() != null) {
                priceDoc.append("min", event.getMinPrice());
            }
            if (event.getMaxPrice() != null) {
                priceDoc.append("max", event.getMaxPrice());
            }
            if (event.getCurrency() != null) {
                priceDoc.append("currency", event.getCurrency());
            }

            if (!priceDoc.isEmpty()) {
                doc.append("priceRange", priceDoc);
            }
        }

        // Add URL and timestamp
        if (event.getUrl() != null) {
            doc.append("url", event.getUrl());
        }

        doc.append("retrievedAt", event.getRetrievedAt());

        return doc;
    }

    /**
     * Convert MongoDB Document to Event object
     *
     * @param doc The document to convert
     * @return Event object
     */
    private Event convertDocumentToEvent(Document doc) {
        if (doc == null) {
            return null;
        }

        Event event = new Event();
        event.setId(doc.getString("_id"));
        event.setName(doc.getString("name"));

        // Extract date information
        if (doc.containsKey("date")) {
            Document dateDoc = (Document) doc.get("date");
            if (dateDoc.containsKey("localDate")) {
                event.setLocalDate(dateDoc.getString("localDate"));
            }
            if (dateDoc.containsKey("localTime")) {
                event.setLocalTime(dateDoc.getString("localTime"));
            }
        }

        // Extract venue and location information
        if (doc.containsKey("venue")) {
            Document venueDoc = (Document) doc.get("venue");

            if (venueDoc.containsKey("name")) {
                event.setVenueName(venueDoc.getString("name"));
            }

            if (venueDoc.containsKey("location")) {
                Document locationDoc = (Document) venueDoc.get("location");

                if (locationDoc.containsKey("city")) {
                    event.setCity(locationDoc.getString("city"));
                }
                if (locationDoc.containsKey("state")) {
                    event.setState(locationDoc.getString("state"));
                }
                if (locationDoc.containsKey("country")) {
                    event.setCountry(locationDoc.getString("country"));
                }
            }
        }

        // Extract price information
        if (doc.containsKey("priceRange")) {
            Document priceDoc = (Document) doc.get("priceRange");

            if (priceDoc.containsKey("min")) {
                event.setMinPrice(priceDoc.getDouble("min"));
            }
            if (priceDoc.containsKey("max")) {
                event.setMaxPrice(priceDoc.getDouble("max"));
            }
            if (priceDoc.containsKey("currency")) {
                event.setCurrency(priceDoc.getString("currency"));
            }
        }

        // Extract URL and timestamp
        if (doc.containsKey("url")) {
            event.setUrl(doc.getString("url"));
        }

        if (doc.containsKey("retrievedAt")) {
            event.setRetrievedAt(doc.getLong("retrievedAt"));
        }

        return event;
    }
}