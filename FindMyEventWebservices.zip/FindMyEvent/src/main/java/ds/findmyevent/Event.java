package ds.findmyevent;

import java.util.Date;

/**
 * Model class representing an event from Ticketmaster
 *
 * @author [Your Name] [Your Andrew ID]
 */
public class Event {
    private String id;
    private String name;
    private String localDate;
    private String localTime;
    private String venueName;
    private String city;
    private String state;
    private String country;
    private Double minPrice;
    private Double maxPrice;
    private String currency;
    private String url;
    private long retrievedAt;

    // Default constructor
    public Event() {
        this.retrievedAt = System.currentTimeMillis();
    }

    // Constructor with ID and name
    public Event(String id, String name) {
        this.id = id;
        this.name = name;
        this.retrievedAt = System.currentTimeMillis();
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocalDate() {
        return localDate;
    }

    public void setLocalDate(String localDate) {
        this.localDate = localDate;
    }

    public String getLocalTime() {
        return localTime;
    }

    public void setLocalTime(String localTime) {
        this.localTime = localTime;
    }

    public String getVenueName() {
        return venueName;
    }

    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Double getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(Double minPrice) {
        this.minPrice = minPrice;
    }

    public Double getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(Double maxPrice) {
        this.maxPrice = maxPrice;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getRetrievedAt() {
        return retrievedAt;
    }

    public void setRetrievedAt(long retrievedAt) {
        this.retrievedAt = retrievedAt;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Event: ").append(name).append("\n");

        if (localDate != null) {
            sb.append("Date: ").append(localDate);
            if (localTime != null) {
                sb.append(" at ").append(localTime);
            }
            sb.append("\n");
        }

        if (venueName != null) {
            sb.append("Venue: ").append(venueName).append("\n");
        }

        sb.append("Location: ");
        if (city != null) {
            sb.append(city);
            if (state != null || country != null) {
                sb.append(", ");
            }
        }

        if (state != null) {
            sb.append(state);
            if (country != null) {
                sb.append(", ");
            }
        }

        if (country != null) {
            sb.append(country);
        }
        sb.append("\n");

        if (minPrice != null && maxPrice != null && currency != null) {
            sb.append(String.format("Price Range: %.2f - %.2f %s\n", minPrice, maxPrice, currency));
        }

        if (url != null) {
            sb.append("URL: ").append(url).append("\n");
        }

        sb.append("Retrieved: ").append(new Date(retrievedAt));

        return sb.toString();
    }
}