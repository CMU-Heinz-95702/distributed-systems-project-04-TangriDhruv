package ds.findmyevent;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
//import Event;

/**
 * Service class for interacting with the Ticketmaster API
 *
 * @author [Your Name] [Your Andrew ID]
 */
public class TicketMasterService {
    private final String apiKey;
    private final String baseUrl;
    private final HttpClient httpClient;
    private final Gson gson;

    /**
     * Constructor with API key
     *
     * @param apiKey Ticketmaster API key
     */
    public TicketMasterService(String apiKey) {
        this.apiKey = apiKey;
        this.baseUrl = "https://app.ticketmaster.com/discovery/v2/events.json";
        this.httpClient = HttpClient.newHttpClient();
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    /**
     * Search for events by name/keyword
     *
     * @param keyword The search keyword
     * @param size Number of results to return
     * @return List of Event objects
     * @throws IOException If an I/O error occurs
     * @throws InterruptedException If the operation is interrupted
     */
    public List<Event> searchByName(String keyword, int size) throws IOException, InterruptedException {
        String encodedKeyword = URLEncoder.encode(keyword, StandardCharsets.UTF_8);
        String url = baseUrl + "?apikey=" + apiKey + "&keyword=" + encodedKeyword + "&size=" + size;

        String response = sendRequest(url);
        return parseEvents(response);
    }

    /**
     * Search for events by country code
     *
     * @param countryCode The country code (e.g., US, GB, CA)
     * @param size Number of results to return
     * @return List of Event objects
     * @throws IOException If an I/O error occurs
     * @throws InterruptedException If the operation is interrupted
     */
    public List<Event> searchByCountry(String countryCode, int size) throws IOException, InterruptedException {
        String url = baseUrl + "?apikey=" + apiKey + "&countryCode=" + countryCode + "&size=" + size;

        String response = sendRequest(url);
        return parseEvents(response);
    }

    /**
     * Get all events (limited by size)
     *
     * @param size Number of results to return
     * @return List of Event objects
     * @throws IOException If an I/O error occurs
     * @throws InterruptedException If the operation is interrupted
     */
    public List<Event> getAllEvents(int size) throws IOException, InterruptedException {
        String url = baseUrl + "?apikey=" + apiKey + "&size=" + size;

        String response = sendRequest(url);
        return parseEvents(response);
    }

    /**
     * Send HTTP request to Ticketmaster API
     *
     * @param url The complete URL with query parameters
     * @return The response body as string
     * @throws IOException If an I/O error occurs
     * @throws InterruptedException If the operation is interrupted
     */
    private String sendRequest(String url) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Accept", "application/json")
                .GET()
                .build();

        System.out.println("Sending request to Ticketmaster API...");
        HttpResponse<String> response = httpClient.send(request, BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new IOException("API request failed with status code: " + response.statusCode());
        }

        return response.body();
    }

    /**
     * Parse JSON response into a list of Event objects
     *
     * @param jsonResponse The JSON response from Ticketmaster API
     * @return List of Event objects
     */
    private List<Event> parseEvents(String jsonResponse) {
        List<Event> events = new ArrayList<>();
        JsonObject root = gson.fromJson(jsonResponse, JsonObject.class);

        // Check if we have any events
        if (!root.has("_embedded") || !root.getAsJsonObject("_embedded").has("events")) {
            return events;
        }

        JsonArray eventArray = root.getAsJsonObject("_embedded").getAsJsonArray("events");

        for (JsonElement element : eventArray) {
            JsonObject eventObj = element.getAsJsonObject();
            Event event = new Event();

            // Extract event ID and name
            event.setId(eventObj.get("id").getAsString());
            event.setName(eventObj.get("name").getAsString());

            // Extract date information
            if (eventObj.has("dates") && eventObj.getAsJsonObject("dates").has("start")) {
                JsonObject start = eventObj.getAsJsonObject("dates").getAsJsonObject("start");
                if (start.has("localDate")) {
                    event.setLocalDate(start.get("localDate").getAsString());
                }
                if (start.has("localTime")) {
                    event.setLocalTime(start.get("localTime").getAsString());
                }
            }

            // Extract venue information
            if (eventObj.has("_embedded") && eventObj.getAsJsonObject("_embedded").has("venues")) {
                JsonArray venues = eventObj.getAsJsonObject("_embedded").getAsJsonArray("venues");
                if (venues.size() > 0) {
                    JsonObject venueObj = venues.get(0).getAsJsonObject();

                    if (venueObj.has("name")) {
                        event.setVenueName(venueObj.get("name").getAsString());
                    }

                    // Extract city
                    if (venueObj.has("city") && venueObj.getAsJsonObject("city").has("name")) {
                        event.setCity(venueObj.getAsJsonObject("city").get("name").getAsString());
                    }

                    // Extract state
                    if (venueObj.has("state") && venueObj.getAsJsonObject("state").has("name")) {
                        event.setState(venueObj.getAsJsonObject("state").get("name").getAsString());
                    }

                    // Extract country
                    if (venueObj.has("country") && venueObj.getAsJsonObject("country").has("name")) {
                        event.setCountry(venueObj.getAsJsonObject("country").get("name").getAsString());
                    }
                }
            }

            // Extract price range
            if (eventObj.has("priceRanges") && eventObj.getAsJsonArray("priceRanges").size() > 0) {
                JsonObject priceRange = eventObj.getAsJsonArray("priceRanges").get(0).getAsJsonObject();

                if (priceRange.has("min")) {
                    event.setMinPrice(priceRange.get("min").getAsDouble());
                }

                if (priceRange.has("max")) {
                    event.setMaxPrice(priceRange.get("max").getAsDouble());
                }

                if (priceRange.has("currency")) {
                    event.setCurrency(priceRange.get("currency").getAsString());
                }
            }

            // Extract URL
            if (eventObj.has("url")) {
                event.setUrl(eventObj.get("url").getAsString());
            }

            events.add(event);
        }

        return events;
    }
}