package ds.findmyevent;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private MongoDBRepository mongoRepository;

    @Override
    public void init() throws ServletException {
        // Initialize MongoDB repository
        mongoRepository = new MongoDBRepository("mongodb+srv://tangridhruv:QAZwsxEDC123@cluster0.04eod.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", "project4db", "events");

        try {
            mongoRepository.connect();
        } catch (Exception e) {
            throw new ServletException("Failed to connect to MongoDB", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Fetch analytics data
        Map<String, Object> analytics = mongoRepository.getAnalytics();
        request.setAttribute("analytics", analytics);

        // Fetch logs - using the getRecentLogs method from the enhanced MongoDBRepository
        List<Document> logs = mongoRepository.getRecentLogs(50);  // Get the 50 most recent logs
        request.setAttribute("logs", logs);

        // Forward to the JSP page
        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }

    @Override
    public void destroy() {
        // Clean up resources
        if (mongoRepository != null) {
            mongoRepository.close();
        }
    }
}